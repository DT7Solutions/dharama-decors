<?php
	/* Forms settings */
	$subj = "New message from 'Ruizarch'"; //letter subject
	$to = 'yourname@domain.com'; // Enter Your E-mail
	$from = 'admin@domain.com'; // Admin e-mail
	$fromName = 'Ruizarch'; // Your company name
	$charset = 'UTF-8';
?>
